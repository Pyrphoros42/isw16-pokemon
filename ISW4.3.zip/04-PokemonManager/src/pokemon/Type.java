package pokemon;

/**
 * @author paul
 *
 */
public enum Type {
	/**  */
	Fire, Water, Poison 
}
